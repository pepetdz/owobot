# Cheat for owo

* ### [Download Latest Release](https://github.com/ahihiyou20/discord-selfbot-owo-bot/tags)
[![GitHub issues](https://img.shields.io/github/issues/sudo-do/discord-selfbot-owo-bot?label=Open%20%C4%B0ssues)](https://github.com/sudo-do/discord-selfbot-owo-bot/issues)
[![GitHub forks](https://img.shields.io/github/forks/sudo-do/discord-selfbot-owo-bot)](https://github.com/sudo-do/discord-selfbot-owo-bot/network)
[![GitHub stars](https://img.shields.io/github/stars/sudo-do/discord-selfbot-owo-bot)](https://github.com/sudo-do/discord-selfbot-owo-bot/stargazers)


setup is quite simple you dont have to do anything special just run the file
enter your token
enter the id of the channel, if you don't know how to do that https://support.discord.com/hc/en-us/articles/206346498-Kullan%C4%B1c%C4%B1-Sunucu-Mesaj-ID-sini-Nerden-Bulurum-


**Your account must have a valid owo profile already, this bot cant run efficiency on new generated accounts**
 You need a team (army) and some gems before start botting, thats because this bot is cant build a perfect account from zero **yet**

its normal your *bot* can sleep after some time thats for not get banned from owo

also it automatically uses gemsz which is not perfect yet but works perfect

feel free to open issues

**Credit: sudo**
**Lastest version: Beta 1.0.7**
